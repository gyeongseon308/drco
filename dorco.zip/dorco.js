$(document).ready(function(){
    let i = 0;
    let count = $(".dorco_text>ul").length;

    $(".next").click(function(){
        $(".dorco_img").stop().animate({"margin-top":"-200vh"},500,function(){
            $(".dorco_img>li:first-child").appendTo(".dorco_img");
            $(".dorco_img").css({"margin-top":"-100vh"});
        });

        if(i == count-1){
            i = 0;
        }else{
            i++;
        }
        show();

    });

    $(".prev").click(function(){
        $(".dorco_img").stop().animate({"margin-top":"0vh"},1000,function(){
            $(".dorco_img>li:last-child").prependTo(".dorco_img");
            $(".dorco_img").css({"margin-top":"-100vh"});
        });

        if(i == 0){
            i = count-1;
        }else{
            i--;
        }
        show();

    });

    function show(){
        $(".txt_1").stop().css({"top":"-300px"});
        $(".txt_2").stop().css({"top":"-250px"});
        $(".banner_txt").stop().fadeOut();
        $(".banner_txt").eq(i).stop().fadeIn(function(){
            $(".txt_1").stop().animate({"top":"0px"},1000);
            $(".txt_2").stop().animate({"top":"0px"},1000);
        });
        }
});
